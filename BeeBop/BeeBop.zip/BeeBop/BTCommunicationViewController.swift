//
//  BTCommunicationHandler.swift
//  Bouncer
//
//  Created by Sean Deneen on 4/9/16.
//  Copyright © 2016 Bouncer. All rights reserved.
//
// Handles all communication with the device via BlueTooth, analyzes data, and acts accordingly.

import UIKit
import CoreBluetooth
import QuartzCore

/// The option to add a \n or \r or \r\n to the end of the send message
// TODO remove eventually, came as part of example HM-10 app
enum MessageOption: Int {
    case NoLineEnding = 0
    case Newline = 1
    case CarriageReturn = 2
    case CarriageReturnAndNewline = 3
}

/// The option to add a \n to the end of the received message (to make it more readable)
// TODO remove eventually, came as part of example HM-10 app
enum ReceivedMessageOption: Int {
    case Nothing = 0
    case Newline = 1
}

// Status of the device
enum DeviceStatus: Int {
    case Disconnected = 0
    case Deactivated = 1
    case Activated = 2
    case Alerted = 3
}

// Status of the device (global)
var deviceStatus: DeviceStatus = .Disconnected
// Message received from BT so far, necessary to piece together message fragments
var messageSoFar = ""


class BTCommunicationViewController: UIViewController, NRFManagerDelegate {
// MARK: Functions
    
    override func viewDidAppear(animated: Bool) {
        nrfManager.delegate = self
    }
    
//MARK: NRFManagerDelegate

    // called when a message is received from the connected device
    func nrfReceivedData(nrfManager: NRFManager, data: NSData?, string: String?) {
        // do anything you need to do
    }
    
    // TODO replace with push notification alert for testing! So we know right away if it disconnects
    func nrfDidDisconnect(nrfManager: NRFManager) {
        // reloadView()
        let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
        hud.mode = MBProgressHUDMode.Text
        hud.labelText = "Disconnected from Device"
        hud.hide(true, afterDelay: 1.0)
        deviceStatus = .Disconnected
    }
    
    
    // TODO same as previous func
    /*func serialHandlerDidChangeState(newState: CBCentralManagerState) {
        if newState != .PoweredOn {
            let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
            hud.mode = MBProgressHUDMode.Text
            hud.labelText = "Bluetooth turned off"
            hud.hide(true, afterDelay: 1.0)
            deviceStatus = .Disconnected
        }
    }*/
}